# AnimeCloud Advanced (Stream Proxy + Bot + Mini App)

This project combines a high-performance Telegram Streaming Proxy with a dynamic Mini App bot.

## Features

- **Telegram Streaming**: Streams video files directly from Telegram with seeking support (Range requests).
- **Smart Caching**: Caches chunks locally for performance.
- **Telegram Bot**: 
    - Forward video files to the bot to catalog them.
    - Set metadata (MAL ID, Episode Number, Label, Quality).
- **Mini App Frontend**: 
    - Built-in Telegram Mini App (`/start` to open).
    - Browse animes, episodes, and watch directly in the app.
- **API**: Comprehensive API for the frontend.

## Setup

1.  **Environment Variables**:
    Create a `.env` file:
    ```env
    API_ID=your_api_id
    API_HASH=your_api_hash
    BOT_TOKEN=your_bot_token
    ADMIN_IDS=12345678,87654321
    WEBAPP_URL=https://your-domain.com
    ```

2.  **Run with Docker**:
    ```bash
    docker-compose up -d --build
    ```

3.  **Run Locally**:
    ```bash
    pip install -r requirements.txt
    uvicorn app.main:app --reload
    ```

## Usage

1.  **Start the Bot**: Send `/start` to your bot.
2.  **Add Content**:
    - Forward a video file to the bot.
    - The bot will acknowledge receipt.
    - Reply with metadata: `mal_id episode label [quality]`
    - Example: `52991 1 Episode-1 1080p`
3.  **Watch**: Click the "Open AnimeCloud" button in the bot to launch the Mini App.
