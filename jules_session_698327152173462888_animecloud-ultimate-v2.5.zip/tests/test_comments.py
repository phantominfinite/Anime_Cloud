import pytest
from httpx import AsyncClient, ASGITransport
from app.main import app
from app.db.session import Base
import pytest_asyncio

# We reuse the setup_db fixture logic, but might need to ensure it runs
# We can just rely on the test_api.py one or copy it.
# Let's just create a new test file with its own fixtures to be safe and independent.

@pytest_asyncio.fixture(scope="module")
async def setup_db():
    from app.db.session import engine
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    yield
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.drop_all)

@pytest.mark.asyncio
async def test_comments_and_likes(setup_db):
    transport = ASGITransport(app=app)
    anime_id = "1" 
    
    async with AsyncClient(transport=transport, base_url="http://test") as ac:
        # 1. Post a comment
        comment_payload = {
            "user_name": "TestUser",
            "text": "This is a test comment."
        }
        response = await ac.post(f"/api/anime/{anime_id}/comments", json=comment_payload)
        assert response.status_code == 200
        assert response.json() == {"ok": True}

        # 2. Get comments and verify
        response = await ac.get(f"/api/anime/{anime_id}/comments")
        assert response.status_code == 200
        comments = response.json()
        assert len(comments) == 1
        assert comments[0]["user"] == "TestUser"
        assert comments[0]["text"] == "This is a test comment."
        assert comments[0]["likes"] == 0
        comment_id = comments[0]["id"]

        # 3. Like the comment
        response = await ac.post(f"/api/comments/{comment_id}/like")
        assert response.status_code == 200
        assert response.json()["likes"] == 1

        # 4. Verify like count persisted
        response = await ac.get(f"/api/anime/{anime_id}/comments")
        assert response.status_code == 200
        comments = response.json()
        assert comments[0]["likes"] == 1
