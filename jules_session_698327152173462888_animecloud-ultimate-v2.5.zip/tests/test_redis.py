import pytest
import asyncio
from app.services.redis_cache import redis_service

@pytest.mark.asyncio
async def test_redis_connection():
    # Attempt to connect
    await redis_service.connect()
    assert redis_service.client is not None
    await redis_service.close()

@pytest.mark.asyncio
async def test_redis_set_get():
    await redis_service.connect()
    key = "test_key"
    value = {"foo": "bar", "num": 123}
    
    await redis_service.set(key, value, expire=10)
    cached = await redis_service.get(key)
    
    assert cached == value
    assert cached['foo'] == 'bar'
    
    await redis_service.delete(key)
    cached_after_delete = await redis_service.get(key)
    assert cached_after_delete is None
    
    await redis_service.close()
