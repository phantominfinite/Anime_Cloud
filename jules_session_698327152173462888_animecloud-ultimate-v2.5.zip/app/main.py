import logging
from contextlib import asynccontextmanager
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.responses import JSONResponse
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.middleware.cors import CORSMiddleware
from app.db.session import engine, Base
from app.services.telegram import telegram_service
from app.core.config import settings
from app.api.v1.endpoints import anime, system, user

logging.basicConfig(level=settings.LOG_LEVEL)
logger = logging.getLogger(__name__)

@asynccontextmanager
async def lifespan(app: FastAPI):
    # Startup
    logger.info("Initializing Database...")
    async with engine.begin() as conn:
        await conn.run_sync(Base.metadata.create_all)
    
    logger.info("Initializing Telegram Service...")
    if settings.API_ID:
        try:
            await telegram_service.start()
        except Exception as e:
            logger.error(f"Failed to start Telegram Service: {e}")
    
    yield
    # Shutdown
    logger.info("Shutting down...")
    await telegram_service.stop()

app = FastAPI(title="Anime Stream Proxy", version="2.0.0", lifespan=lifespan)

# Middleware
app.add_middleware(GZipMiddleware, minimum_size=1000)
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Global Exception Handler
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Global error: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"ok": False, "error": "Internal Server Error", "detail": str(exc)},
    )

# API Router
app.include_router(anime.router, prefix="/api", tags=["api"])
app.include_router(system.router, prefix="/api/system", tags=["system"])
app.include_router(user.router, prefix="/api", tags=["user"])

# Static Files (Frontend)
# Mount static last to avoid overriding API routes
app.mount("/", StaticFiles(directory="app/static", html=True), name="static")
