import asyncio
import logging
from typing import Dict, Set, Optional
from pyrogram import Client
from app.services.cache import cache_service

logger = logging.getLogger(__name__)

class SmartDownloader:
    def __init__(self, client: Client, chunk_size: int = 1024 * 1024):
        self.client = client
        self.chunk_size = chunk_size
        self.active_downloads: Dict[str, Set[int]] = {} # file_id -> set of chunk_indices being downloaded
        self.locks: Dict[str, asyncio.Lock] = {} # file_id -> Lock for synchronizing access to active_downloads
        self._semaphore = asyncio.Semaphore(5) # Global limit of concurrent download tasks

    async def _get_lock(self, file_id: str) -> asyncio.Lock:
        if file_id not in self.locks:
            self.locks[file_id] = asyncio.Lock()
        return self.locks[file_id]

    async def prefetch_chunks(self, file_id: str, start_index: int, count: int = 3):
        """
        Fire and forget download tasks for upcoming chunks.
        """
        for i in range(count):
            idx = start_index + i
            # Check if already cached
            if await cache_service.exists(file_id, idx):
                continue
            
            # Check if already downloading
            lock = await self._get_lock(file_id)
            async with lock:
                if file_id not in self.active_downloads:
                    self.active_downloads[file_id] = set()
                if idx in self.active_downloads[file_id]:
                    continue
                self.active_downloads[file_id].add(idx)

            # Spawn task
            asyncio.create_task(self._download_worker(file_id, idx))

    async def _download_worker(self, file_id: str, chunk_index: int):
        async with self._semaphore:
            try:
                # Double check cache just in case
                if await cache_service.exists(file_id, chunk_index):
                    return

                logger.debug(f"prefetching chunk {chunk_index} for {file_id[:10]}...")
                
                # Fetch single chunk using stream_media with limit=1
                # Note: stream_media returns a generator.
                stream = self.client.stream_media(
                    file_id,
                    offset=chunk_index,
                    limit=1
                )
                
                async for chunk in stream:
                    await cache_service.save_chunk(file_id, chunk_index, chunk)
                    break # Should be only one chunk if limit=1? Pyrogram chunks are 1MB usually.
                    
            except Exception as e:
                logger.error(f"Error in download worker for {file_id}/{chunk_index}: {e}")
            finally:
                lock = await self._get_lock(file_id)
                async with lock:
                    if file_id in self.active_downloads:
                        self.active_downloads[file_id].discard(chunk_index)

    async def get_chunk(self, file_id: str, chunk_index: int) -> Optional[bytes]:
        """
        Get a specific chunk, waiting for it if it's currently being downloaded,
        or triggering a download if it's missing.
        """
        # 1. Check Cache
        data = await cache_service.get_chunk(file_id, chunk_index)
        if data:
            # Trigger prefetch for next ones
            await self.prefetch_chunks(file_id, chunk_index + 1, count=3)
            return data

        # 2. If not in cache, we MUST download it now.
        # Check if it's already "active" (being prefetched)
        lock = await self._get_lock(file_id)
        is_active = False
        async with lock:
            if file_id in self.active_downloads and chunk_index in self.active_downloads[file_id]:
                is_active = True
        
        if is_active:
            # Wait for it to appear in cache
            for _ in range(50): # Wait up to 5 seconds
                await asyncio.sleep(0.1)
                data = await cache_service.get_chunk(file_id, chunk_index)
                if data:
                    await self.prefetch_chunks(file_id, chunk_index + 1, count=3)
                    return data
            # If timeout, fall through to force download (maybe worker failed)

        # 3. Force download synchronously (well, await it)
        await self._download_worker(file_id, chunk_index)
        
        # 4. Return result
        data = await cache_service.get_chunk(file_id, chunk_index)
        if data:
            await self.prefetch_chunks(file_id, chunk_index + 1, count=3)
        return data

downloader = None 

def init_downloader(client: Client):
    global downloader
    downloader = SmartDownloader(client)
