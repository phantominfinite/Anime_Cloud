import logging
import asyncio
from typing import AsyncGenerator, Dict, Any
from pyrogram import Client, filters
from pyrogram.types import Message, InlineKeyboardMarkup, InlineKeyboardButton, WebAppInfo, InlineQuery, InlineQueryResultArticle, InputTextMessageContent
from pyrogram.errors import RPCError
from sqlalchemy import select, update
from sqlalchemy.ext.asyncio import AsyncSession
from pyrogram.handlers import MessageHandler, InlineQueryHandler

from app.core.config import settings
from app.services.cache import cache_service
from app.services.downloader import init_downloader, downloader
from app.services.websocket import manager
from app.services.jikan import jikan_service
from app.db.session import async_session_factory
from app.db.models import Anime, Episode
import json

logger = logging.getLogger(__name__)

# Pending state for users adding episodes: {user_id: {"file_id": ..., "file_unique_id": ..., "file_size": ...}}
PENDING_UPLOADS: Dict[int, Dict[str, Any]] = {}

class TelegramService:
    def __init__(self):
        self.api_id = settings.API_ID
        self.api_hash = settings.API_HASH
        self.bot_token = settings.BOT_TOKEN
        self.client = None
        self.chunk_size = 1024 * 1024 # 1MB Pyrogram default
        self.admin_ids = [int(x) for x in settings.ADMIN_IDS.split(",")] if hasattr(settings, "ADMIN_IDS") else []

    async def start(self):
        if not self.client:
            logger.info("Starting Telegram Client...")
            self.client = Client(
                "bot_session", 
                api_id=self.api_id, 
                api_hash=self.api_hash, 
                bot_token=self.bot_token, 
                in_memory=True
            )
            
            self.client.add_handler(MessageHandler(self.handle_start, filters.command("start")))
            self.client.add_handler(MessageHandler(self.handle_search, filters.command("search")))
            self.client.add_handler(MessageHandler(self.handle_forwarded_video, filters.video | filters.document))
            self.client.add_handler(MessageHandler(self.handle_text, filters.text & ~filters.command(["start", "search"])))
            self.client.add_handler(InlineQueryHandler(self.handle_inline_query))

            await self.client.start()
            init_downloader(self.client) # Initialize downloader with client
            logger.info("Telegram Client Started")

    async def stop(self):
        if self.client:
            await self.client.stop()
            logger.info("Telegram Client Stopped")

    async def stream_file(self, file_id: str, offset: int = 0, limit: int = 0) -> AsyncGenerator[bytes, None]:
        if not self.client:
             raise RuntimeError("Client not initialized")
        
        if not downloader:
             raise RuntimeError("Downloader not initialized")

        start_chunk_idx = offset // self.chunk_size
        start_byte_in_chunk = offset % self.chunk_size
        
        current_chunk_idx = start_chunk_idx
        bytes_yielded = 0
        
        # Trigger prefetch for the first few chunks immediately
        await downloader.prefetch_chunks(file_id, current_chunk_idx, count=5)
        
        while True:
            if limit > 0 and bytes_yielded >= limit:
                break
            
            # Use downloader to get chunk (it handles caching and fetching)
            chunk_data = await downloader.get_chunk(file_id, current_chunk_idx)
            
            if not chunk_data:
                break
                
            chunk = chunk_data
            if current_chunk_idx == start_chunk_idx and start_byte_in_chunk > 0:
                chunk = chunk[start_byte_in_chunk:]
            
            if limit > 0:
                remaining = limit - bytes_yielded
                if len(chunk) > remaining:
                    chunk = chunk[:remaining]
            
            yield chunk
            bytes_yielded += len(chunk)
            current_chunk_idx += 1

    # --- BOT HANDLERS ---

    async def handle_start(self, client: Client, message: Message):
        # Determine WebApp URL
        webapp_url = settings.WEBAPP_URL if hasattr(settings, "WEBAPP_URL") else "https://google.com" 
        # User should set WEBAPP_URL to the deployed domain.
        
        await message.reply(
            f"Hello {message.from_user.first_name}! 👋\nClick below to open the Anime App.",
            reply_markup=InlineKeyboardMarkup([
                [InlineKeyboardButton("📺 Open AnimeCloud", web_app=WebAppInfo(url=webapp_url))]
            ])
        )

    async def handle_inline_query(self, client: Client, inline_query: InlineQuery):
        query = inline_query.query.strip()
        if len(query) < 3:
            return

        results = await jikan_service.search_anime(query)
        webapp_url = settings.WEBAPP_URL if hasattr(settings, "WEBAPP_URL") else "https://google.com"

        articles = []
        for anime in results:
            articles.append(
                InlineQueryResultArticle(
                    title=anime["title"],
                    description=f"{anime.get('type', '?')} • {anime.get('year', '?')} • ⭐ {anime.get('score', 'N/A')}",
                    thumb_url=anime["images"]["jpg"]["image_url"],
                    input_message_content=InputTextMessageContent(
                        f"🎬 **{anime['title']}**\n\n{anime.get('synopsis', '')[:200]}..."
                    ),
                    reply_markup=InlineKeyboardMarkup([
                        [InlineKeyboardButton("📺 Watch Now", web_app=WebAppInfo(url=f"{webapp_url}#anime_{anime['mal_id']}"))]
                    ])
                )
            )
        
        await inline_query.answer(articles, cache_time=300)

    async def handle_search(self, client: Client, message: Message):
        if len(message.command) < 2:
            await message.reply("Usage: `/search <anime name>`")
            return

        query = " ".join(message.command[1:])
        await message.reply(f"🔎 Searching for: {query}...")
        
        results = await jikan_service.search_anime(query)
        
        if not results:
            await message.reply("❌ No results found.")
            return

        text = "🎯 **Search Results:**\n\n"
        for anime in results:
            text += f"• `{anime['mal_id']}` - **{anime['title']}** ({anime.get('year', 'N/A')})\n"
        
        text += "\nCopy the ID to add episodes."
        await message.reply(text)

    async def handle_forwarded_video(self, client: Client, message: Message):
        # Check admin
        if message.from_user.id not in self.admin_ids:
            return

        file = message.video or message.document
        if not file:
            return

        file_id = file.file_id
        file_unique_id = file.file_unique_id
        file_size = file.file_size
        mime_type = file.mime_type
        
        PENDING_UPLOADS[message.from_user.id] = {
            "file_id": file_id,
            "file_unique_id": file_unique_id,
            "file_size": file_size,
            "mime_type": mime_type
        }
        
        await message.reply(
            "✅ File received. Now send metadata in this format:\n"
            "`mal_id episode label [quality]`\n"
            "Example: `52991 1 Episode-1 1080p`"
        )

    async def handle_text(self, client: Client, message: Message):
        user_id = message.from_user.id
        if user_id not in PENDING_UPLOADS:
            return

        text = message.text.strip()
        parts = text.split()
        if len(parts) < 3:
            await message.reply("Invalid format. Usage: `mal_id episode label [quality]`")
            return
            
        mal_id = parts[0]
        episode_number = parts[1]
        
        # Heuristic for quality
        quality = None
        label = ""
        
        if len(parts) >= 4 and parts[-1].lower().endswith('p') and parts[-1][:-1].isdigit():
             quality = parts[-1]
             label = " ".join(parts[2:-1])
        else:
             label = " ".join(parts[2:])

        file_data = PENDING_UPLOADS.pop(user_id)
        
        async with async_session_factory() as session:
            # Check if anime exists, if not create it (dummy title for now)
            result = await session.execute(select(Anime).filter(Anime.mal_id == mal_id))
            anime = result.scalars().first()
            
            if not anime:
                # Fetch metadata from Jikan
                await message.reply(f"⏳ Fetching metadata for Anime ID: {mal_id}...")
                details = await jikan_service.get_anime(int(mal_id))
                
                if details:
                    anime = Anime(
                        mal_id=mal_id, 
                        title=details.get("title"),
                        description=details.get("synopsis"),
                        image_url=details.get("images", {}).get("jpg", {}).get("large_image_url"),
                        genres=json.dumps(details.get("genres", [])),
                        score=details.get("score"),
                        status=details.get("status"),
                        studios=json.dumps(details.get("studios", [])),
                        type=details.get("type"),
                        year=details.get("year"),
                        season=details.get("season"),
                        rating=details.get("rating"),
                        duration=details.get("duration"),
                        trailer_url=details.get("trailer", {}).get("embed_url"),
                        rank=details.get("rank")
                    )
                else:
                    # Fallback
                    anime = Anime(mal_id=mal_id, title=f"Anime {mal_id}")
                
                session.add(anime)
                await session.commit()
            
            # Create Episode
            episode = Episode(
                anime_mal_id=mal_id,
                episode_number=episode_number,
                label=label,
                quality=quality,
                file_id=file_data["file_id"],
                file_unique_id=file_data["file_unique_id"],
                file_size=file_data["file_size"],
                mime_type=file_data.get("mime_type", "video/mp4")
            )
            session.add(episode)
            await session.commit()
        
        # Broadcast new episode event
        await manager.broadcast({
            "type": "new_episode",
            "data": {
                "anime_mal_id": mal_id,
                "episode": episode_number,
                "label": label,
                "quality": quality,
                "url": f"/api/stream/{file_data['file_id']}"
            }
        })
            
        await message.reply(f"✅ Saved Episode {episode_number} for Anime {mal_id}")

telegram_service = TelegramService()
