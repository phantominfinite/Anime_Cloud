import os
import aiofiles
import logging
import hashlib
import shutil
import asyncio
from app.core.config import settings
from app.services.redis_cache import redis_service

logger = logging.getLogger(__name__)

class CacheService:
    def __init__(self):
        self.cache_dir = settings.CACHE_DIR
        if not os.path.exists(self.cache_dir):
            os.makedirs(self.cache_dir)

    def _get_chunk_path(self, file_id: str, chunk_index: int) -> str:
        # Hashing file_id to avoid directory traversal or long names
        safe_file_id = hashlib.md5(file_id.encode()).hexdigest()
             
        file_dir = os.path.join(self.cache_dir, safe_file_id)
        if not os.path.exists(file_dir):
            os.makedirs(file_dir)
        return os.path.join(file_dir, str(chunk_index))
    
    async def exists(self, file_id: str, chunk_index: int) -> bool:
        path = self._get_chunk_path(file_id, chunk_index)
        return os.path.exists(path)

    async def get_chunk(self, file_id: str, chunk_index: int) -> bytes | None:
        path = self._get_chunk_path(file_id, chunk_index)
        if os.path.exists(path):
            try:
                # Update Redis Access Log
                asyncio.create_task(redis_service.update_access(path))
                
                async with aiofiles.open(path, mode='rb') as f:
                    return await f.read()
            except Exception as e:
                logger.error(f"Error reading cache for {file_id}/{chunk_index}: {e}")
                return None
        return None

    async def save_chunk(self, file_id: str, chunk_index: int, data: bytes):
        path = self._get_chunk_path(file_id, chunk_index)
        temp_path = f"{path}.tmp"
        try:
            # Atomic write pattern: write to temp then rename
            async with aiofiles.open(temp_path, mode='wb') as f:
                await f.write(data)
            os.rename(temp_path, path)
            
            # Update Redis Access Log
            asyncio.create_task(redis_service.update_access(path))
            
            # Check size occasionally (random sample to avoid lock step)
            if chunk_index % 10 == 0:
               asyncio.create_task(self._check_cache_size())

        except Exception as e:
            logger.error(f"Error writing cache for {file_id}/{chunk_index}: {e}")
            if os.path.exists(temp_path):
                try:
                    os.remove(temp_path)
                except: pass

    async def _check_cache_size(self):
        # Max cache size: 2GB (hardcoded for now)
        MAX_SIZE = 2 * 1024 * 1024 * 1024 
        try:
            # Fast check of total size
            total_size = await self._get_total_size()
            
            if total_size > MAX_SIZE:
                # Need to evict
                logger.info(f"Cache size {total_size} exceeds limit {MAX_SIZE}. Evicting...")
                
                # Get coldest files from Redis
                # Evict 20 at a time
                eviction_candidates = await redis_service.get_coldest_files(count=20)
                
                for fp in eviction_candidates:
                    try:
                        if os.path.exists(fp):
                             size = os.path.getsize(fp)
                             os.remove(fp)
                             total_size -= size
                    except Exception as e:
                        logger.warning(f"Failed to delete {fp}: {e}")
                        
        except Exception as e:
            logger.error(f"Error checking cache size: {e}")

    async def _get_total_size(self):
        # This is still potentially slow if millions of files, 
        # but relying on `du` or similar via shell might be faster on Linux
        # For now, simplistic python walk is okay, but let's run it in executor
        loop = asyncio.get_running_loop()
        return await loop.run_in_executor(None, self._sync_get_size)

    def _sync_get_size(self):
        total_size = 0
        for root, dirs, files in os.walk(self.cache_dir):
             for f in files:
                 fp = os.path.join(root, f)
                 try:
                     total_size += os.path.getsize(fp)
                 except: pass
        return total_size

    async def clear_cache(self):
        """Clears the entire cache."""
        try:
            shutil.rmtree(self.cache_dir)
            os.makedirs(self.cache_dir)
        except Exception as e:
            logger.error(f"Failed to clear cache: {e}")

cache_service = CacheService()
