from fastapi import APIRouter, Depends, HTTPException, Header, Request, Query, WebSocket, WebSocketDisconnect
from fastapi.responses import StreamingResponse
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select, func, or_
from typing import List, Optional, Dict, Any

from pydantic import BaseModel
from app.db.session import get_db
from app.db.models import Anime, Episode, Comment
from app.services.telegram import telegram_service
from app.services.websocket import manager
from app.services.redis_cache import redis_service
from app.services.search import search_service
from app.core.config import settings

router = APIRouter()

@router.websocket("/ws")
@router.websocket("/ws/{anime_mal_id}")
async def websocket_endpoint(websocket: WebSocket, anime_mal_id: Optional[str] = None):
    await manager.connect(websocket, anime_mal_id)
    try:
        while True:
            # Keep alive
            await websocket.receive_text()
    except WebSocketDisconnect:
        await manager.disconnect(websocket, anime_mal_id)

@router.get("/health", response_model=Dict[str, Any])
async def health(db: AsyncSession = Depends(get_db)) -> Dict[str, Any]:
    """
    Health check endpoint.
    Returns:
        dict: Status and counts of animes/episodes.
    """
    try:
        anime_count = await db.scalar(select(func.count(Anime.id)))
        episode_count = await db.scalar(select(func.count(Episode.id)))
        return {"ok": True, "anime_count": anime_count, "episodes_count": episode_count}
    except Exception as e:
        return {"ok": False, "error": str(e)}

@router.get("/stats")
async def stats(db: AsyncSession = Depends(get_db)):
    return await health(db)

@router.get("/anime/list", response_model=Dict[str, List[Dict[str, Any]]])
async def list_animes(
    skip: int = Query(0, ge=0), 
    limit: int = Query(100, le=1000), 
    db: AsyncSession = Depends(get_db)
) -> Dict[str, List[Dict[str, Any]]]:
    """
    Returns a list of all animes with their episodes.
    
    Args:
        skip (int): Pagination offset.
        limit (int): Pagination limit.
        db (AsyncSession): Database session.
        
    Returns:
        dict: Grouped episodes by Anime MAL ID.
    """
    cache_key = f"anime_list:{skip}:{limit}"
    cached_data = await redis_service.get(cache_key)
    if cached_data:
        return cached_data

    result = await db.execute(select(Episode).offset(skip).limit(limit))
    episodes = result.scalars().all()
    
    data: Dict[str, List[Dict[str, Any]]] = {}
    for ep in episodes:
        if ep.anime_mal_id not in data:
            data[ep.anime_mal_id] = []
        
        data[ep.anime_mal_id].append({
            "episode": ep.episode_number,
            "label": ep.label,
            "quality": ep.quality,
            "url": f"/api/stream/{ep.file_id}",
            "original_url": f"https://t.me/file/{ep.file_id}" 
        })
    
    await redis_service.set(cache_key, data, expire=60)
    return data

@router.get("/anime/{mal_id}/episodes", response_model=List[Dict[str, Any]])
async def get_anime_episodes(mal_id: str, db: AsyncSession = Depends(get_db)) -> List[Dict[str, Any]]:
    """
    Get all episodes for a specific anime.
    """
    result = await db.execute(
        select(Episode)
        .filter(Episode.anime_mal_id == mal_id)
        .order_by(Episode.episode_number) 
    )
    episodes = result.scalars().all()
    
    return [
        {
            "episode": ep.episode_number,
            "label": ep.label,
            "quality": ep.quality,
            "url": f"/api/stream/{ep.file_id}"
        }
        for ep in episodes
    ]

class CommentCreate(BaseModel):
    user_name: str
    text: str

@router.get("/anime/{mal_id}/comments")
async def get_comments(mal_id: str, db: AsyncSession = Depends(get_db)):
    result = await db.execute(
        select(Comment)
        .filter(Comment.anime_mal_id == mal_id)
        .order_by(Comment.created_at.desc())
        .limit(50)
    )
    comments = result.scalars().all()
    return [{
        "id": c.id,
        "user": c.user_name,
        "text": c.text,
        "likes": c.likes,
        "date": c.created_at.strftime("%Y/%m/%d")
    } for c in comments]

@router.post("/anime/{mal_id}/comments")
async def post_comment(mal_id: str, comment_in: CommentCreate, db: AsyncSession = Depends(get_db)):
    comment = Comment(
        anime_mal_id=mal_id,
        user_name=comment_in.user_name,
        text=comment_in.text,
        likes=0
    )
    db.add(comment)
    await db.commit()
    await db.refresh(comment)
    
    # Broadcast new comment
    await manager.broadcast({
        "type": "new_comment",
        "data": {
            "id": comment.id,
            "anime_mal_id": mal_id,
            "user": comment.user_name,
            "text": comment.text,
            "likes": 0,
            "date": comment.created_at.strftime("%Y/%m/%d")
        }
    })
    
    return {"ok": True}

@router.post("/comments/{comment_id}/like")
async def like_comment(comment_id: int, db: AsyncSession = Depends(get_db)):
    comment = await db.get(Comment, comment_id)
    if not comment:
        raise HTTPException(status_code=404, detail="Comment not found")
        
    comment.likes += 1
    await db.commit()
    await db.refresh(comment)
    
    # Optional: Broadcast like update if needed, for now we just return it
    
    return {"ok": True, "likes": comment.likes}

@router.get("/search", response_model=Dict[str, List[Dict[str, Any]]])
async def search(q: str = Query(..., min_length=1), db: AsyncSession = Depends(get_db)) -> Dict[str, List[Dict[str, Any]]]:
    """
    Search for episodes or animes by title or label.
    Refactored to use SearchService for smarter anime lookup.
    """
    # First search for Anime
    animes = await search_service.search_anime(db, q)
    
    data: Dict[str, List[Dict[str, Any]]] = {}
    
    if animes:
        # If we found anime, fetch their episodes
        anime_ids = [a['mal_id'] for a in animes]
        stmt = select(Episode).filter(Episode.anime_mal_id.in_(anime_ids))
        result = await db.execute(stmt)
        episodes = result.scalars().all()
        
        for ep in episodes:
            if ep.anime_mal_id not in data:
                data[ep.anime_mal_id] = []
            data[ep.anime_mal_id].append({
                "episode": ep.episode_number,
                "label": ep.label,
                "quality": ep.quality,
                "url": f"/api/stream/{ep.file_id}"
            })
            
    # Fallback: Search episodes directly if no anime found (or to augment results)
    # This covers cases where episode label matches but anime title doesn't (rare but possible)
    if not data:
        stmt = select(Episode).join(Anime).filter(Episode.label.ilike(f"%{q}%"))
        result = await db.execute(stmt.limit(50))
        episodes = result.scalars().all()
        for ep in episodes:
            if ep.anime_mal_id not in data:
                data[ep.anime_mal_id] = []
            data[ep.anime_mal_id].append({
                "episode": ep.episode_number,
                "label": ep.label,
                "quality": ep.quality,
                "url": f"/api/stream/{ep.file_id}"
            })
            
    return data

@router.get("/system/health")
async def system_health(db: AsyncSession = Depends(get_db)):
    try:
        # Check DB
        await db.execute(select(1))
        # Check Redis
        await redis_service.set("health_check", "ok", expire=5)
        
        return {"status": "operational", "services": {"db": "ok", "redis": "ok"}}
    except Exception as e:
        return {"status": "degraded", "error": str(e)}

@router.get("/stream/{file_id}")
async def stream_video(
    file_id: str, 
    request: Request,
    range: str = Header(None)
):
    """
    Streams video file from Telegram with Range support (Partial Content).
    This allows seeking in video players.
    """
    from app.db.session import async_session_factory
    
    async with async_session_factory() as db:
        result = await db.execute(select(Episode).filter(Episode.file_id == file_id))
        episode = result.scalars().first()
        
        if not episode:
            raise HTTPException(status_code=404, detail="File not found in database.")
            
        file_size = episode.file_size
        content_type = episode.mime_type
        file_name = f"{episode.label or 'video'}.mp4"

    start = 0
    end = file_size - 1
    status_code = 200
    content_length = file_size

    if range:
        try:
            status_code = 206
            range_str = range.strip().lower().replace('bytes=', '')
            range_parts = range_str.split('-')
            
            if not range_parts[0] and len(range_parts) > 1 and range_parts[1]:
                # Suffix byte range request (e.g. bytes=-500)
                suffix = int(range_parts[1])
                start = max(0, file_size - suffix)
                end = file_size - 1
            else:
                start = int(range_parts[0]) if range_parts[0] else 0
                end = int(range_parts[1]) if len(range_parts) > 1 and range_parts[1] else file_size - 1
            
            if start > end or start >= file_size:
                 headers = {"Content-Range": f"bytes */{file_size}"}
                 raise HTTPException(status_code=416, detail="Range Not Satisfiable", headers=headers)
                
            content_length = end - start + 1
            
        except ValueError:
             pass

    async def iterfile():
        try:
            # We use our service to stream chunks.
            # Note: Streaming directly from Telegram might be slow for jumps.
            # But the CacheService helps.
            async for chunk in telegram_service.stream_file(file_id, offset=start, limit=content_length):
                yield chunk
        except Exception as e:
            # Log error
            print(f"Streaming error: {e}")
            # If we already started sending headers, we can't change status code.
            # But FastAPI handles generator errors by closing connection usually.
            raise HTTPException(status_code=500, detail="Streaming failed")

    headers = {
        "Content-Disposition": f'inline; filename="{file_name}"', 
        "Accept-Ranges": "bytes",
        "Content-Length": str(content_length),
        "Content-Type": content_type,
    }

    if status_code == 206:
        headers["Content-Range"] = f"bytes {start}-{end}/{file_size}"

    return StreamingResponse(
        iterfile(), 
        status_code=status_code, 
        media_type=content_type, 
        headers=headers
    )
