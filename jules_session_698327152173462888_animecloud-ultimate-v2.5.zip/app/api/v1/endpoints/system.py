from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncSession
from app.db.session import get_db
from app.services.redis_cache import redis_service
from app.services.websocket import manager

router = APIRouter()

@router.get("/health")
async def get_system_health(db: AsyncSession = Depends(get_db)):
    # Check Database
    db_status = "unknown"
    try:
        await db.execute(text("SELECT 1"))
        db_status = "online"
    except Exception as e:
        db_status = f"offline: {str(e)}"

    # Check Cache (Redis)
    cache_status = "unknown"
    try:
        await redis_service.connect()
        cache_type = "mock" if redis_service.is_mock else "redis"
        cache_status = f"online ({cache_type})"
    except Exception as e:
        cache_status = f"offline: {str(e)}"

    # Check Websocket / Users
    active_connections = len(manager.active_connections)

    return {
        "status": "operational",
        "components": {
            "database": db_status,
            "cache": cache_status,
            "realtime_users": active_connections
        }
    }
