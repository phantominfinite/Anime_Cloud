from fastapi import APIRouter, Depends, HTTPException, Body
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy import select
from typing import List, Dict, Any, Optional

from app.db.session import get_db
from app.db.models import User, UserAnime
from app.services.auth import get_current_user
from pydantic import BaseModel

router = APIRouter()

class UserAnimeUpdate(BaseModel):
    status: str # plan_to_watch, watching, completed, dropped
    is_favorite: bool
    score: Optional[int] = None
    progress_episode: Optional[str] = None

@router.post("/auth/login")
async def login(user: User = Depends(get_current_user)):
    """
    Verifies Telegram Init Data and returns the user.
    Called by frontend on startup.
    """
    return {
        "ok": True,
        "user": {
            "id": user.id,
            "telegram_id": user.telegram_id,
            "first_name": user.first_name,
            "username": user.username,
            "photo_url": user.photo_url
        }
    }

@router.get("/user/library")
async def get_library(user: User = Depends(get_current_user), db: AsyncSession = Depends(get_db)):
    """
    Returns user's library (favorites, history).
    """
    result = await db.execute(select(UserAnime).filter(UserAnime.user_id == user.id))
    items = result.scalars().all()
    
    return {
        "ok": True,
        "library": [
            {
                "anime_mal_id": item.anime_mal_id,
                "status": item.status,
                "is_favorite": item.is_favorite,
                "score": item.score,
                "progress": item.progress_episode
            }
            for item in items
        ]
    }

@router.post("/user/library/{mal_id}")
async def update_library(
    mal_id: str, 
    data: UserAnimeUpdate, 
    user: User = Depends(get_current_user), 
    db: AsyncSession = Depends(get_db)
):
    """
    Updates or creates a library entry.
    """
    result = await db.execute(
        select(UserAnime).filter(UserAnime.user_id == user.id, UserAnime.anime_mal_id == mal_id)
    )
    entry = result.scalars().first()
    
    if not entry:
        entry = UserAnime(
            user_id=user.id,
            anime_mal_id=mal_id,
            status=data.status,
            is_favorite=data.is_favorite,
            score=data.score,
            progress_episode=data.progress_episode
        )
        db.add(entry)
    else:
        entry.status = data.status
        entry.is_favorite = data.is_favorite
        if data.score is not None:
            entry.score = data.score
        if data.progress_episode is not None:
            entry.progress_episode = data.progress_episode
            
    await db.commit()
    return {"ok": True}
