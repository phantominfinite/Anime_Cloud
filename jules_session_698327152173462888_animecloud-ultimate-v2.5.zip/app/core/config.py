from pydantic_settings import BaseSettings
from pydantic import Field

class Settings(BaseSettings):
    API_ID: int = Field(..., env="API_ID")
    API_HASH: str = Field(..., env="API_HASH")
    BOT_TOKEN: str = Field(..., env="BOT_TOKEN")
    
    ADMIN_API_KEY: str = Field("secret", env="ADMIN_API_KEY")
    ADMIN_IDS: str = Field("", env="ADMIN_IDS")
    
    # Updated default to Postgres, but fallback to sqlite if needed (though docker-compose uses pg)
    DATABASE_URL: str = Field("postgresql+asyncpg://anime:animepass@localhost:5432/anime_db", env="DATABASE_URL")
    
    REDIS_URL: str = Field("redis://localhost:6379/0", env="REDIS_URL")
    
    CACHE_DIR: str = Field("cache", env="CACHE_DIR")
    
    LOG_LEVEL: str = Field("INFO", env="LOG_LEVEL")
    WEBAPP_URL: str = Field("https://google.com", env="WEBAPP_URL")

    class Config:
        env_file = ".env"
        extra = "ignore"

settings = Settings()
